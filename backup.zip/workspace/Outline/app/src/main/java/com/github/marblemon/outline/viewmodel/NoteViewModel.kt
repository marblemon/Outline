package com.github.marblemon.outline.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.marblemon.outline.data.Note
import com.github.marblemon.outline.data.NoteRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class NoteViewModel(private val repository: NoteRepository) : ViewModel() {
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()
    
    val allNotes = combine(
        repository.getAllNotes(),
        _searchQuery,
        _selectedTag
    ) { notes, query, tag ->
        var filteredNotes = notes
        if (query.isNotEmpty()) {
            filteredNotes = filteredNotes.filter { note ->
                note.title.contains(query, ignoreCase = true) ||
                note.content.contains(query, ignoreCase = true)
            }
        }
        if (tag != null) {
            filteredNotes = filteredNotes.filter { note ->
                note.tags.contains(tag, ignoreCase = true)
            }
        }
        filteredNotes
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )
    
    val allTags = repository.getAllTags()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }
    
    fun setSelectedTag(tag: String?) {
        _selectedTag.value = tag
    }
    
    fun getNoteById(id: String): Flow<Note?> = repository.getNoteByIdFlow(id)
    
    fun insertNote(note: Note) {
        viewModelScope.launch {
            repository.insertNote(note)
        }
    }
    
    fun updateNote(note: Note) {
        viewModelScope.launch {
            repository.updateNote(note)
        }
    }
    
    fun deleteNote(id: String) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }
    
    fun clearDeletedNotes() {
        viewModelScope.launch {
            repository.clearDeletedNotes()
        }
    }
    
    fun getNotesByTag(tag: String): Flow<List<Note>> = repository.getNotesByTag(tag)
    
    fun searchNotes(query: String): Flow<List<Note>> = repository.searchNotes(query)
}
