package com.github.marblemon.outline.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY updatedAt DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE isDeleted = 0 AND (title LIKE :searchQuery OR content LIKE :searchQuery) ORDER BY updatedAt DESC")
    fun searchNotes(searchQuery: String): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE isDeleted = 0 AND tags LIKE :tag ORDER BY updatedAt DESC")
    fun getNotesByTag(tag: String): Flow<List<Note>>

    @Query("SELECT DISTINCT tags FROM notes WHERE isDeleted = 0 AND tags != ''")
    fun getAllTags(): Flow<List<String>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNoteById(id: String): Note?
    
    @Query("SELECT * FROM notes WHERE id = :id")
    fun getNoteByIdFlow(id: String): Flow<Note?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Update
    suspend fun updateNote(note: Note)

    @Query("UPDATE notes SET isDeleted = 1, updatedAt = :updatedAt WHERE id = :id")
    suspend fun deleteNote(id: String, updatedAt: java.util.Date)

    @Query("DELETE FROM notes WHERE isDeleted = 1")
    suspend fun clearDeletedNotes()
}
