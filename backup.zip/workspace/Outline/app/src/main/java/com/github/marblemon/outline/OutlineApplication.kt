package com.github.marblemon.outline

import android.app.Application
import com.github.marblemon.outline.data.AppDatabase
import com.github.marblemon.outline.data.NoteRepository

class OutlineApplication : Application() {
    
    private val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { NoteRepository(database.noteDao()) }
}
