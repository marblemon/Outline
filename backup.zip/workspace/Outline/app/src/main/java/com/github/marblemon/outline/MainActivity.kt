package com.github.marblemon.outline

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.SearchView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.marblemon.outline.adapter.NoteAdapter
import com.github.marblemon.outline.data.Note
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.github.marblemon.outline.R
import com.github.marblemon.outline.viewmodel.NoteViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

class MainActivity : AppCompatActivity() {
    
    private lateinit var notesRecyclerView: RecyclerView
    private lateinit var fabAddNote: FloatingActionButton
    private lateinit var noteAdapter: NoteAdapter
    private lateinit var viewModel: NoteViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        setupViews()
        setupViewModel()
        observeNotes()
        setupClickListeners()
    }
    
    private fun setupViews() {
        notesRecyclerView = findViewById(R.id.notesRecyclerView)
        fabAddNote = findViewById(R.id.fabAddNote)
        
        noteAdapter = NoteAdapter(
            onItemClick = { note ->
                val intent = Intent(this, NoteEditorActivity::class.java).apply {
                    putExtra("NOTE_ID", note.id)
                }
                startActivity(intent)
            },
            onItemLongClick = { note ->
                showDeleteDialog(note)
                true
            }
        )
        
        notesRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = noteAdapter
        }
    }
    
    private fun setupViewModel() {
        val app = application as OutlineApplication
        viewModel = NoteViewModel(app.repository)
    }
    
    private fun observeNotes() {
        CoroutineScope(Dispatchers.Main).launch {
            viewModel.allNotes.collect { notes ->
                noteAdapter.submitList(notes)
            }
        }
    }
    
    private fun setupClickListeners() {
        fabAddNote.setOnClickListener {
            val intent = Intent(this, NoteEditorActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun showDeleteDialog(note: Note) {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_title_delete)
            .setMessage(R.string.dialog_message_delete)
            .setPositiveButton(R.string.btn_confirm) { _, _ ->
                viewModel.deleteNote(note.id)
            }
            .setNegativeButton(R.string.btn_dismiss, null)
            .show()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setSearchQuery(newText ?: "")
                return true
            }
        })
        
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_about -> {
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
