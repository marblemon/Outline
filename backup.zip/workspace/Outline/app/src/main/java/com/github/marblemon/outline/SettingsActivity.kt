package com.github.marblemon.outline

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.appbar.MaterialToolbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.toList
import com.github.marblemon.outline.data.Note
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class SettingsActivity : AppCompatActivity() {
    
    private lateinit var backupButton: Button
    private lateinit var restoreButton: Button
    
    companion object {
        private const val REQUEST_CODE_PERMISSION = 1001
        private const val REQUEST_CODE_PICK_FILE = 1002
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings_title)
        
        backupButton = findViewById(R.id.backupButton)
        restoreButton = findViewById(R.id.restoreButton)
        
        setupClickListeners()
    }
    
    private fun setupClickListeners() {
        backupButton.setOnClickListener {
            if (hasStoragePermission()) {
                performBackup()
            } else {
                requestStoragePermission()
            }
        }
        
        restoreButton.setOnClickListener {
            if (hasStoragePermission()) {
                openFilePicker()
            } else {
                requestStoragePermission()
            }
        }
    }
    
    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ doesn't require external storage permission
            true
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ doesn't require external storage permission
            performBackup()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_CODE_PERMISSION
            )
        }
    }
    
    private fun performBackup() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = application as OutlineApplication
                val notes = mutableListOf<Note>()
                app.repository.getAllNotes().collect { noteList ->
                    notes.addAll(noteList)
                }
                
                // Create backup content
                val backupContent = notes.joinToString("\n") { note ->
                    "${note.id}|${note.title}|${note.content}|${note.tags}|${note.createdAt.time}|${note.updatedAt.time}|${note.isDeleted}"
                }
                
                // Write to file
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                val fileName = "outline_backup_${dateFormat.format(Date())}.txt"
                
                val file = File(getExternalFilesDir(null), fileName)
                FileOutputStream(file).use { outputStream ->
                    outputStream.write(backupContent.toByteArray())
                }
                
                launch(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "备份成功: $fileName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                launch(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "备份失败: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
        }
        startActivityForResult(intent, REQUEST_CODE_PICK_FILE)
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                performRestore(uri)
            }
        }
    }
    
    private fun performRestore(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                contentResolver.openInputStream(uri)?.use { inputStream ->
                    val content = inputStream.bufferedReader().use { it.readText() }
                    
                    val lines = content.split("\n")
                    val app = application as OutlineApplication
                    
                    for (line in lines) {
                        if (line.isBlank()) continue
                        
                        val parts = line.split("|")
                        if (parts.size >= 7) {
                            val note = com.github.marblemon.outline.data.Note(
                                id = parts[0],
                                title = parts[1],
                                content = parts[2],
                                tags = parts[3],
                                createdAt = Date(parts[4].toLong()),
                                updatedAt = Date(parts[5].toLong()),
                                isDeleted = parts[6].toBoolean()
                            )
                            runBlocking {
                                app.repository.insertNote(note)
                            }
                        }
                    }
                }
                
                launch(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "恢复成功", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                launch(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "恢复失败: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == REQUEST_CODE_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "权限已授予", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "需要存储权限才能进行备份/恢复", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
