package com.github.marblemon.outline

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.github.marblemon.outline.data.Note
import com.github.marblemon.outline.databinding.ActivityNoteEditorBinding
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.runBlocking
import java.util.*

class NoteEditorActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityNoteEditorBinding
    private var noteId: String? = null
    private var note: Note? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        // 获取传递的笔记ID（如果有）
        noteId = intent.getStringExtra("NOTE_ID")
        
        if (noteId != null) {
            // 编辑现有笔记
            loadNote()
            supportActionBar?.title = "编辑笔记"
        } else {
            // 创建新笔记
            note = Note()
            supportActionBar?.title = "新建笔记"
        }
        
        setupUI()
    }
    
    private fun setupUI() {
        // 设置文本监听器
        binding.titleEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            
            override fun afterTextChanged(s: Editable?) {
                note = note?.copy(title = s.toString()) ?: note?.copy(title = s.toString())
            }
        })
        
        binding.contentEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            
            override fun afterTextChanged(s: Editable?) {
                note = note?.copy(content = s.toString()) ?: note?.copy(content = s.toString())
            }
        })
        
        binding.tagsEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            
            override fun afterTextChanged(s: Editable?) {
                note = note?.copy(tags = s.toString()) ?: note?.copy(tags = s.toString())
            }
        })
        
        // 文本格式化按钮
        binding.boldButton.setOnClickListener {
            // 这里可以实现文本加粗功能
            Toast.makeText(this, "加粗功能待实现", Toast.LENGTH_SHORT).show()
        }
        
        binding.italicButton.setOnClickListener {
            // 这里可以实现文本斜体功能
            Toast.makeText(this, "斜体功能待实现", Toast.LENGTH_SHORT).show()
        }
        
        binding.smallTextButton.setOnClickListener {
            binding.contentEditText.textSize = 12f
        }
        
        binding.normalTextButton.setOnClickListener {
            binding.contentEditText.textSize = 16f
        }
        
        binding.largeTextButton.setOnClickListener {
            binding.contentEditText.textSize = 20f
        }
        
        // 保存按钮
        binding.saveButton.setOnClickListener {
            saveNote()
        }
        
        // 取消按钮
        binding.cancelButton.setOnClickListener {
            finish()
        }
    }
    
    private fun loadNote() {
        // 从数据库加载笔记
        Thread {
            val app = application as OutlineApplication
            val loadedNote = runBlocking {
                app.repository.getNoteById(noteId!!)
            }
            runOnUiThread {
                if (loadedNote != null) {
                    note = loadedNote
                    binding.titleEditText.setText(loadedNote.title)
                    binding.contentEditText.setText(loadedNote.content)
                    binding.tagsEditText.setText(loadedNote.tags)
                }
            }
        }.start()
    }
    
    private fun saveNote() {
        val title = binding.titleEditText.text.toString()
        val content = binding.contentEditText.text.toString()
        val tags = binding.tagsEditText.text.toString()
        
        if (title.isBlank() && content.isBlank()) {
            Toast.makeText(this, "笔记标题和内容不能都为空", Toast.LENGTH_SHORT).show()
            return
        }
        
        val newNote = if (note != null) {
            note!!.copy(
                title = title,
                content = content,
                tags = tags,
                updatedAt = Date()
            )
        } else {
            Note(
                title = title,
                content = content,
                tags = tags
            )
        }
        
        Thread {
            val app = application as OutlineApplication
            runBlocking {
                app.repository.insertNote(newNote)
            }
            runOnUiThread {
                Toast.makeText(this, R.string.toast_note_saved, Toast.LENGTH_SHORT).show()
                finish()
            }
        }.start()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
