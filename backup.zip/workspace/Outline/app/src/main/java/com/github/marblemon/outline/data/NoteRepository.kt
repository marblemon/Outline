package com.github.marblemon.outline.data

import kotlinx.coroutines.flow.Flow
import java.util.Date

class NoteRepository(private val noteDao: NoteDao) {
    
    fun getAllNotes(): Flow<List<Note>> = noteDao.getAllNotes()
    
    fun searchNotes(query: String): Flow<List<Note>> = 
        noteDao.searchNotes("%$query%")
    
    fun getNotesByTag(tag: String): Flow<List<Note>> = 
        noteDao.getNotesByTag("%$tag%")
    
    fun getAllTags(): Flow<List<String>> = noteDao.getAllTags()
    
    suspend fun getNoteById(id: String): Note? = noteDao.getNoteById(id)
    
    fun getNoteByIdFlow(id: String): Flow<Note?> = noteDao.getNoteByIdFlow(id)
    
    suspend fun insertNote(note: Note) = noteDao.insertNote(note)
    
    suspend fun updateNote(note: Note) = noteDao.updateNote(note)
    
    suspend fun deleteNote(id: String) = noteDao.deleteNote(id, Date())
    
    suspend fun clearDeletedNotes() = noteDao.clearDeletedNotes()
}
