package com.github.marblemon.outline.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.github.marblemon.outline.data.Note
import com.github.marblemon.outline.R
import java.text.SimpleDateFormat
import java.util.*

class NoteAdapter(
    private val onItemClick: (Note) -> Unit,
    private val onItemLongClick: (Note) -> Boolean
) : ListAdapter<Note, NoteAdapter.NoteViewHolder>(NoteDiffCallback()) {

    class NoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        val contentTextView: TextView = itemView.findViewById(R.id.contentTextView)
        val tagsTextView: TextView = itemView.findViewById(R.id.tagsTextView)
        val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        val tagsContainer: ViewGroup = itemView.findViewById(R.id.tagsContainer)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = getItem(position)
        holder.titleTextView.text = note.title.ifEmpty { "无标题" }
        holder.contentTextView.text = note.content.ifEmpty { "点击编辑内容" }
        
        // 格式化日期
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        holder.dateTextView.text = dateFormat.format(note.updatedAt)

        // 处理标签显示
        if (note.tags.isNotEmpty()) {
            holder.tagsTextView.visibility = View.VISIBLE
            holder.tagsTextView.text = note.tags
        } else {
            holder.tagsTextView.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            onItemClick(note)
        }
        
        holder.itemView.setOnLongClickListener {
            onItemLongClick(note)
        }
    }

    class NoteDiffCallback : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(oldItem: Note, newItem: Note): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Note, newItem: Note): Boolean {
            return oldItem == newItem
        }
    }
}
